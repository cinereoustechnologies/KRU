<?php
wp_enqueue_style( 'masterstudy-analytics-instructor-page' );
wp_enqueue_style( 'masterstudy-analytics-components' );
wp_enqueue_script( 'masterstudy-analytics-instructor-page' );

$courses_columns = array(
	array(
		'title' => __( '№', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'number',
	),
	array(
		'title' => __( 'Course name', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'course_name',
	),
	array(
		'title' => __( 'Enrollments', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'enrollments',
	),
	array(
		'title' => __( 'Revenue', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'revenue',
	),
	array(
		'title' => __( 'Views', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'views',
	),
	array(
		'title' => __( 'Course creation date', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'date_created',
	),
	array(
		'title' => '',
		'data'  => 'course_id',
	),
);

wp_localize_script(
	'masterstudy-analytics-instructor-page',
	'instructor_page_data',
	array(
		'courses' => $courses_columns,
		'titles'  => array(
			'revenue_chart'     => esc_html__( 'Revenue', 'masterstudy-lms-learning-management-system-pro' ),
			'enrollments_chart' => array(
				'total'  => esc_html__( 'Total', 'masterstudy-lms-learning-management-system-pro' ),
				'unique' => esc_html__( 'Unique', 'masterstudy-lms-learning-management-system-pro' ),
			),
		),
	)
);

$charts_data = array(
	array(
		'title' => __( 'Total Revenue', 'masterstudy-lms-learning-management-system-pro' ),
		'id'    => 'revenue-chart',
	),
	array(
		'title' => __( 'Total Enrollments', 'masterstudy-lms-learning-management-system-pro' ),
		'id'    => 'enrollments-chart',
	),
);

$tables_data = array(
	array(
		'title' => __( 'Courses', 'masterstudy-lms-learning-management-system-pro' ),
		'id'    => 'courses-table',
	),
);
?>

<div class="masterstudy-analytics-instructor-page">
	<div class="masterstudy-analytics-instructor-page__header">
		<?php
		STM_LMS_Templates::show_lms_template(
			'components/back-link',
			array(
				'id'  => 'instructor',
				'url' => masterstudy_get_current_url( array( 'user', 'user_id', 'role' ) ),
			)
		);
		?>
		<h1 class="masterstudy-analytics-instructor-page__title">
			<?php
			$default_title       = __( 'Instructor', 'masterstudy-lms-learning-management-system-pro' );
			$default_title_class = 'masterstudy-analytics-instructor-page__title-role_self';

			if ( isset( $_GET['user_id'] ) ) {
				$user_info = get_userdata( intval( $_GET['user_id'] ) );

				if ( $user_info && ( ! empty( $user_info->first_name ) || ! empty( $user_info->last_name ) ) ) {
					$default_title_class = '';
					?>
					<span class="masterstudy-analytics-instructor-page__name">
						<?php echo esc_html( $user_info->first_name . ' ' . $user_info->last_name ); ?>
					</span>
					<?php
				}
			}
			?>
			<span class="masterstudy-analytics-instructor-page__role <?php echo esc_attr( $default_title_class ); ?>">
				<?php echo esc_html( $default_title ); ?>
			</span>
		</h1>
		<div class="masterstudy-analytics__date">
			<div class="masterstudy-analytics__date-label"></div>
			<div class="masterstudy-analytics__date-value"></div>
		</div>
	</div>
	<?php
	STM_LMS_Templates::show_lms_template(
		'components/analytics/datepicker-modal',
		array(
			'id' => 'instructor',
		)
	);
	?>
	<div class="masterstudy-analytics-instructor-page-line" data-chart-id="revenue-chart">
		<div class="masterstudy-analytics-instructor-page-line__wrapper">
			<div class="masterstudy-analytics-instructor-page-line__content">
				<?php STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'line-chart-loader' ) ); ?>
				<div class="masterstudy-analytics-instructor-page-line__header">
					<h2 class="masterstudy-analytics-instructor-page-line__title">
						<?php echo esc_html__( 'Total Revenue', 'masterstudy-lms-learning-management-system-pro' ); ?>
					</h2>
					<div id="revenue-total" class="masterstudy-analytics-instructor-page-line__single-total"></div>
				</div>
				<div class="masterstudy-analytics-instructor-page-line__chart">
					<?php
					STM_LMS_Templates::show_lms_template(
						'components/analytics/line-chart',
						array(
							'id' => 'revenue',
						)
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="masterstudy-analytics-instructor-page-line" data-chart-id="enrollments-chart">
		<div class="masterstudy-analytics-instructor-page-line__wrapper">
			<div class="masterstudy-analytics-instructor-page-line__content">
				<?php STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'line-chart-loader' ) ); ?>
				<div class="masterstudy-analytics-instructor-page-line__header">
					<h2 class="masterstudy-analytics-instructor-page-line__title">
						<?php echo esc_html__( 'Total Enrollments', 'masterstudy-lms-learning-management-system-pro' ); ?>
					</h2>
					<div class="masterstudy-analytics-instructor-page-line__total-wrapper">
						<div class="masterstudy-analytics-instructor-page-line__total">
							<div class="masterstudy-analytics-instructor-page-line__total-title">
								<?php echo esc_html__( 'Total', 'masterstudy-lms-learning-management-system-pro' ); ?>:
							</div>
							<div id="enrollments-total" class="masterstudy-analytics-instructor-page-line__total-value"></div>
						</div>
						<div class="masterstudy-analytics-instructor-page-line__total">
							<div class="masterstudy-analytics-instructor-page-line__total-title">
								<?php echo esc_html__( 'Unique', 'masterstudy-lms-learning-management-system-pro' ); ?>:
							</div>
							<div id="unique-total" class="masterstudy-analytics-instructor-page-line__total-value"></div>
						</div>
					</div>
				</div>
				<div class="masterstudy-analytics-instructor-page-line__chart">
					<?php
					STM_LMS_Templates::show_lms_template(
						'components/analytics/line-chart',
						array(
							'id' => 'enrollments',
						)
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="masterstudy-analytics-instructor-page-table" data-chart-id="courses-table">
		<?php STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'table-loader' ) ); ?>
		<div class="masterstudy-analytics-instructor-page-table__wrapper">
			<div class="masterstudy-analytics-instructor-page-table__header">
				<div class="masterstudy-analytics-instructor-page-table__title">
					<?php echo esc_html__( 'Courses', 'masterstudy-lms-learning-management-system-pro' ); ?>
				</div>
				<input type="text" id="table-courses-search" class="masterstudy-analytics-instructor-page-table__search" placeholder="<?php echo esc_html__( 'Search', 'masterstudy-lms-learning-management-system-pro' ); ?>">
			</div>
			<?php
			STM_LMS_Templates::show_lms_template(
				'components/analytics/datatable',
				array(
					'id'      => 'courses',
					'columns' => $courses_columns,
				)
			);
			?>
		</div>
	</div>
</div>
