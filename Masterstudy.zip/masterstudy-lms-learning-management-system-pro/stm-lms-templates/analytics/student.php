<?php
use MasterStudy\Lms\Plugin\Addons;

wp_enqueue_style( 'masterstudy-analytics-student-page' );
wp_enqueue_style( 'masterstudy-analytics-components' );
wp_enqueue_script( 'masterstudy-analytics-student-page' );

$stats_types = array(
	'passed',
	'failed',
);

$revenue_stats_types = array(
	'revenue',
	'orders',
);

$courses_stats_types = array(
	'enrolled',
	'completed',
	'in_progress',
	'not_started',
);

$main_stats_types = array( 'reviews' );

if ( is_ms_lms_addon_enabled( Addons::COURSE_BUNDLE ) ) {
	array_splice( $main_stats_types, 0, 0, 'bundles' );
}

if ( is_ms_lms_addon_enabled( 'enterprise_courses' ) ) {
	array_splice( $main_stats_types, 1, 0, 'groups' );
}

if ( is_ms_lms_addon_enabled( 'certificate_builder' ) ) {
	array_splice( $main_stats_types, 3, 0, 'certificates' );
}

if ( is_ms_lms_addon_enabled( 'point_system' ) ) {
	array_splice( $main_stats_types, 4, 0, 'points' );
}

$courses_columns = array(
	array(
		'title' => __( '№', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'number',
	),
	array(
		'title' => __( 'Course name', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'name',
	),
	array(
		'title' => __( 'Duration', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'duration',
	),
	array(
		'title' => __( 'Started', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'started',
	),
	array(
		'title' => __( 'Progress', 'masterstudy-lms-learning-management-system-pro' ),
		'data'  => 'progress',
	),
);

wp_localize_script(
	'masterstudy-analytics-student-page',
	'student_page_data',
	array(
		'courses' => $courses_columns,
		'titles'  => array(
			'courses_chart' => array(
				'enrolled'  => esc_html__( 'Enrolled', 'masterstudy-lms-learning-management-system-pro' ),
				'completed' => esc_html__( 'Completed', 'masterstudy-lms-learning-management-system-pro' ),
			),
		),
	)
);

$charts_data = array(
	array(
		'title' => __( 'Courses', 'masterstudy-lms-learning-management-system-pro' ),
		'id'    => 'courses-chart',
	),
);

$tables_data = array(
	array(
		'title' => __( 'Courses', 'masterstudy-lms-learning-management-system-pro' ),
		'id'    => 'courses-table',
	),
);
?>

<div class="masterstudy-analytics-student-page">
	<div class="masterstudy-analytics-student-page__header">
		<?php
		STM_LMS_Templates::show_lms_template(
			'components/back-link',
			array(
				'id'  => 'student',
				'url' => masterstudy_get_current_url( array( 'user', 'user_id', 'role' ) ),
			)
		);
		?>
		<h1 class="masterstudy-analytics-student-page__title">
			<?php
			$default_title       = __( 'Student', 'masterstudy-lms-learning-management-system-pro' );
			$default_title_class = 'masterstudy-analytics-student-page__title-role_self';

			if ( isset( $_GET['user_id'] ) ) {
				$user_info = get_userdata( intval( $_GET['user_id'] ) );

				if ( $user_info && ( ! empty( $user_info->first_name ) || ! empty( $user_info->last_name ) ) ) {
					$default_title_class = '';
					?>
					<span class="masterstudy-analytics-student-page__name">
						<?php echo esc_html( $user_info->first_name . ' ' . $user_info->last_name ); ?>
					</span>
					<?php
				}
			}
			?>
			<span class="masterstudy-analytics-student-page__role <?php echo esc_attr( $default_title_class ); ?>">
				<?php echo esc_html( $default_title ); ?>
			</span>
		</h1>
		<div class="masterstudy-analytics__date">
			<div class="masterstudy-analytics__date-label"></div>
			<div class="masterstudy-analytics__date-value"></div>
		</div>
	</div>
	<?php
	STM_LMS_Templates::show_lms_template(
		'components/analytics/datepicker-modal',
		array(
			'id' => 'student',
		)
	);
	?>
	<div class="masterstudy-analytics-student-page-stats masterstudy-analytics-student-page-stats_revenue">
		<div class="masterstudy-analytics-student-page-stats__wrapper">
			<?php foreach ( $revenue_stats_types as $item ) { ?>
				<div class="masterstudy-analytics-student-page-stats__block">
					<?php
					STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'data-loader' ) );
					STM_LMS_Templates::show_lms_template(
						'components/analytics/stats-block',
						array(
							'type' => $item,
						)
					);
					?>
				</div>
			<?php } ?>
		</div>
	</div>
	<div class="masterstudy-analytics-student-page-line" data-chart-id="courses-chart">
		<div class="masterstudy-analytics-student-page-line__wrapper">
			<div class="masterstudy-analytics-student-page-line__content">
				<?php STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'line-chart-loader' ) ); ?>
				<div class="masterstudy-analytics-student-page-line__header">
					<?php echo esc_html__( 'Courses', 'masterstudy-lms-learning-management-system-pro' ); ?>
				</div>
				<div class="masterstudy-analytics-student-page-line__stats">
					<?php foreach ( $courses_stats_types as $item ) { ?>
						<div class="masterstudy-analytics-student-page-stats__block masterstudy-analytics-student-page-stats__block_courses">
							<?php
							STM_LMS_Templates::show_lms_template(
								'components/analytics/stats-block',
								array(
									'type' => $item,
								)
							);
							?>
						</div>
					<?php } ?>
				</div>
				<div class="masterstudy-analytics-student-page-line__chart">
					<?php
					STM_LMS_Templates::show_lms_template(
						'components/analytics/line-chart',
						array(
							'id' => 'courses',
						)
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="masterstudy-analytics-student-page-table" data-chart-id="courses-table">
		<?php STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'table-loader' ) ); ?>
		<div class="masterstudy-analytics-student-page-table__wrapper">
			<?php
			STM_LMS_Templates::show_lms_template(
				'components/analytics/datatable',
				array(
					'id'      => 'courses',
					'columns' => $courses_columns,
				)
			);
			?>
		</div>
	</div>
	<div class="masterstudy-analytics-student-page-types">
		<div class="masterstudy-analytics-student-page-types__wrapper">
			<div class="masterstudy-analytics-student-page-types__content">
				<div class="masterstudy-analytics-student-page-types__header">
					<?php echo esc_html__( 'Quizzes', 'masterstudy-lms-learning-management-system-pro' ); ?>
				</div>
				<div class="masterstudy-analytics-student-page-types__data">
					<?php foreach ( $stats_types as $item ) { ?>
						<div class="masterstudy-analytics-student-page-stats__block masterstudy-analytics-student-page-stats__block_quizzes">
							<?php
							STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'data-loader' ) );
							STM_LMS_Templates::show_lms_template(
								'components/analytics/stats-block',
								array(
									'type' => $item,
								)
							);
							?>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php if ( is_ms_lms_addon_enabled( 'assignments' ) ) { ?>
			<div class="masterstudy-analytics-student-page-types__wrapper">
				<div class="masterstudy-analytics-student-page-types__content">
					<div class="masterstudy-analytics-student-page-types__header">
						<?php
						echo esc_html__( 'Assignments', 'masterstudy-lms-learning-management-system-pro' );
						STM_LMS_Templates::show_lms_template(
							'components/button',
							array(
								'id'            => 'masterstudy-analytics-assignments',
								'title'         => esc_html__( 'Assignments', 'masterstudy-lms-learning-management-system-pro' ),
								'link'          => admin_url( 'edit.php?post_type=stm-user-assignment' ),
								'style'         => 'primary',
								'size'          => 'sm',
								'icon_name'     => 'plus',
								'icon_position' => 'next',
								'target'        => '_blank',
							)
						);
						?>
					</div>
					<div class="masterstudy-analytics-student-page-types__data">
						<?php foreach ( $stats_types as $item ) { ?>
							<div class="masterstudy-analytics-student-page-stats__block masterstudy-analytics-student-page-stats__block_assignments">
								<?php
								STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'data-loader' ) );
								STM_LMS_Templates::show_lms_template(
									'components/analytics/stats-block',
									array(
										'type' => $item,
									)
								);
								?>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
	<div class="masterstudy-analytics-student-page-stats masterstudy-analytics-student-page-stats_main">
		<div class="masterstudy-analytics-student-page-stats__wrapper">
			<?php foreach ( $main_stats_types as $item ) { ?>
				<div class="masterstudy-analytics-student-page-stats__block">
					<?php
					STM_LMS_Templates::show_lms_template( 'components/analytics/loader', array( 'loader_type' => 'data-loader' ) );
					STM_LMS_Templates::show_lms_template(
						'components/analytics/stats-block',
						array(
							'type' => $item,
						)
					);
					?>
				</div>
			<?php } ?>
		</div>
	</div>
</div>
