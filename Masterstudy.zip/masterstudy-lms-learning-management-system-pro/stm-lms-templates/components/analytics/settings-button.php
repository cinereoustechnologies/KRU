<?php
/**
 * @var string $id
 */
?>

<span data-id="masterstudy-settings-button-<?php echo esc_attr( $id ); ?>" class="masterstudy-settings-button"></span>
