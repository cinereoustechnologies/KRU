<?php
/**
 * @var string $id
 */
?>

<canvas id="masterstudy-line-chart-<?php echo esc_attr( $id ); ?>"></canvas>
