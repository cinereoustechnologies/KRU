<?php
/**
 * @var string $id
 */
?>

<canvas id="masterstudy-doughnut-chart-<?php echo esc_attr( $id ); ?>"></canvas>
