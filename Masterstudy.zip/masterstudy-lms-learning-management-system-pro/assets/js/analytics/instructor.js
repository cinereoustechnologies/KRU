(function($) {
    // Fetch data global variables
    let chartsData = null;
    let revenueChart = null;
    let enrollmentsChart = null;
    let table = null;

    // Fetch data
    fetchDataCharts();

    document.addEventListener('datesUpdated', function(event) {
        fetchDataCharts();
        updateTable(routes.instructorCoursesTable, true);
    });

    $(document).ready(function() {
        initializeDatepicker('#masterstudy-datepicker-instructor');

        //Update data
        updateCharts();
        updateTable(routes.instructorCoursesTable);
    });

    // Fetch data methods
    function fetchDataCharts() {
        if ( isDomReady ) {
            showLoaders('.masterstudy-analytics-instructor-page-line');
        }

        api.get( routePrefix + routes.instructorCharts, { date_from: getDateFrom(), date_to: getDateTo() } )
        .then(result => {
            if (result.error_code) {
                return
            }

            chartsData = {
                total_revenue: result.total_revenue,
                total_enrollments: result.total_enrollments,
                unique_enrollments: result.unique_enrollments,
                revenue_chart: {
                    period: result.earnings?.period,
                    items: [
                        { label: instructor_page_data.titles.revenue_chart, values: result.earnings?.values },
                    ]
                },
                enrollments_chart: {
                    period: result.enrollments?.period,
                    items: [
                        { label: instructor_page_data.titles.enrollments_chart.total, values: result.enrollments?.all },
                        { label: instructor_page_data.titles.enrollments_chart.unique, values: result.enrollments?.unique },
                    ]
                },
            }

            updateCharts();
        })
    }

    // Update charts & table methods
    function updateCharts() {
        if (chartsData && isDomReady) {
            if (!revenueChart) {
                revenueChart = createChart(document.getElementById('masterstudy-line-chart-revenue').getContext('2d'), 'line', [], [], true);
            }

            if (!enrollmentsChart) {
                enrollmentsChart = createChart(
                    document.getElementById('masterstudy-line-chart-enrollments').getContext('2d'),
                    'line',
                    chartsData.enrollments_chart.period,
                    chartsData.enrollments_chart.items.map((item, index) => ({
                        label: item.label,
                        data: item.values
                    }))
                );
            }

            updateTotal('#revenue-total', chartsData.total_revenue, 'currency');
            updateTotal('#enrollments-total', chartsData.total_enrollments);
            updateTotal('#unique-total', chartsData.unique_enrollments);
            updateLineChart(revenueChart, chartsData.revenue_chart.period, chartsData.revenue_chart.items);
            updateLineChart(enrollmentsChart, chartsData.enrollments_chart.period, chartsData.enrollments_chart.items);

            hideLoaders('.masterstudy-analytics-instructor-page-line');
        }
    }

    function updateTable(currentRoute, reloadTable = false) {
        if (isDomReady) {
            if (!table  || reloadTable) {

                showLoaders('.masterstudy-analytics-instructor-page-table');

                if (table) {
                    table.clear().destroy();
                    table = null;
                    $('#masterstudy-datatable-courses').empty();
                }

                additionalOptions = {
                    ajax: {
                        url: api.getRouteUrl(routePrefix + currentRoute),
                        type: 'GET',
                        dataType: 'json',
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('X-WP-Nonce', api.getRouteNonce());
                        },
                        data: function (d) {
                            d.date_from = getDateFrom();
                            d.date_to = getDateTo();
                        },
                        dataSrc: function (json) {
                            const pageInfo = $('#masterstudy-datatable-courses').DataTable().page.info();
                            const start = pageInfo.start;

                            json.data = json.data.map((item, index) => {
                                item.number = start + index + 1;

                                if (item.hasOwnProperty('revenue')) {
                                    item.revenue = formatCurrency(item.revenue);
                                }

                                return item;
                            });

                            return json.data;
                        }
                    },
                    columnDefs: [
                        { targets: 0, width: '30px', orderable: false },
                        { targets: instructor_page_data.courses.length - 1, orderable: false },
                        {
                            targets: instructor_page_data.courses.length - 1,
                            data: 'course_id',
                            render: function (data, type, row) {
                                const currentUrl = window.location.href;
                                const newUrl = new URL(currentUrl);
                                const keysToDelete = ['role', 'user', 'user_id'];
                                keysToDelete.forEach(param => newUrl.searchParams.delete(param));
                                newUrl.searchParams.set('course_id', data);
                                newUrl.searchParams.set('course', row.course_name);

                                return renderReportButton(newUrl);
                            }
                        }
                    ]
                };

                table = createDataTable('#masterstudy-datatable-courses', instructor_page_data.courses, additionalOptions);
                observeTableChanges(table);
                hideLoaders('.masterstudy-analytics-instructor-page-table');
            }
        }
    }
})(jQuery);