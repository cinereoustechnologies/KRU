(function($) {
    // Fetch data global variables
    let chartsData = null;
    const routesArray = [routes.reviewsPublishedTable, routes.reviewsPendingTable];
    const totalsArray = ['one', 'two', 'three', 'four', 'five'];
    let coursesChart = null;
    let reviewsTypeChart = null;
    let reviewersTable = null;
    let coursesTable = null;
    let reviewsTable = null;

    // Fetch data
    fetchDataCharts();

    document.addEventListener('datesUpdated', function(event) {
        fetchDataCharts();
        updateTable(routes.reviewedCoursesTable, true);
        updateTable(routes.reviewersTable, true);
        $(`.masterstudy-tabs [data-id="${routes.reviewsPublishedTable}"]`).trigger('click');
    });

    $(document).ready(function() {
        initializeDatepicker('#masterstudy-datepicker-users');

        $('.masterstudy-tabs__item').click(function() {
            const tabRoute = $(this).data('id');
            $(this).addClass('masterstudy-tabs__item_active');
            $(this).siblings().removeClass('masterstudy-tabs__item_active');
            updateTable(tabRoute, true);
        });

        //Update data
        updateCharts();
        updateTable(routes.reviewedCoursesTable);
        updateTable(routes.reviewersTable);
        updateTable(routes.reviewsPublishedTable);
    });

    // Fetch data methods
    function fetchDataCharts() {
        if ( isDomReady ) {
            showLoaders('.masterstudy-analytics-reviews-page-line');
        }

        api.get( routePrefix + routes.reviewsCharts, { date_from: getDateFrom(), date_to: getDateTo() } )
        .then(result => {
            if (result.error_code) {
                return
            }
            chartsData = result;
            updateCharts();
        })
    }

    // Update charts & table methods
    function updateCharts() {
        if (chartsData && isDomReady) {
            if (!reviewsTypeChart) {
                reviewsTypeChart = createChart(
                    document.getElementById('masterstudy-line-chart-reviews-type').getContext('2d'),
                    'line',
                    chartsData.reviews_type_chart.period,
                    chartsData.reviews_type_chart.items.map((item, index) => ({
                        label: item.label,
                        data: item.values
                    }))
                );
            }

            if (!coursesChart) {
                coursesChart = createChart(document.getElementById('masterstudy-line-chart-reviews').getContext('2d'), 'line');
            }

            totalsArray.reverse().forEach((type, index) => {
                updateTotal(`#reviews-totals-${type} .masterstudy-analytics-reviews-page-line__totals-value`, chartsData.total_by_type[index]);
            });
            updateTotal('#reviews-total', chartsData.total);
            updateLineChart(coursesChart, chartsData.courses_chart.period, chartsData.courses_chart.items);
            updateLineChart(reviewsTypeChart, chartsData.reviews_type_chart.period, chartsData.reviews_type_chart.items);

            hideLoaders('.masterstudy-analytics-reviews-page-line');
        }
    }

    function updateTable(currentRoute, reloadTable = false) {
        if (isDomReady) {
            if (!reviewsTable || !reviewersTable || !coursesTable || reloadTable) {
                showLoaders(`[data-chart-id="${currentRoute}-table"]`);

                if (routesArray.includes(currentRoute) && reloadTable) {
                    showLoaders(`[data-chart-id="reviews-table"]`);
                    reviewsTable.clear().destroy();
                    reviewsTable = null;
                    $(`#masterstudy-datatable-${currentRoute}`).empty();
                }

                if (routes.reviewersTable === currentRoute && reloadTable) {
                    reviewersTable.clear().destroy();
                    reviewersTable = null;
                    $(`#masterstudy-datatable-${currentRoute}`).empty();
                }

                if (routes.reviewedCoursesTable === currentRoute && reloadTable) {
                    coursesTable.clear().destroy();
                    coursesTable = null;
                    $(`#masterstudy-datatable-${currentRoute}`).empty();
                }

                additionalOptions = {
                    ajax: {
                        url: api.getRouteUrl(routePrefix + currentRoute),
                        type: 'GET',
                        dataType: 'json',
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('X-WP-Nonce', api.getRouteNonce());
                        },
                        data: function (d) {
                            d.date_from = getDateFrom();
                            d.date_to = getDateTo();
                        },
                        dataSrc: function (json) {
                            const pageInfo = $(`#masterstudy-datatable-${currentRoute}`).DataTable().page.info();
                            const start = pageInfo?.start ?? 0;

                            json.data = json.data.map((item, index) => {
                                item.number = start + index + 1;
                                return item;
                            });

                            if (routesArray.includes(currentRoute)) {
                                updateTotal( '#reviews-table-total', json.recordsTotal);
                            }

                            return json.data;
                        }
                    }
                }

                if (routesArray.includes(currentRoute)) {
                    additionalOptions.columnDefs = [
                        { targets: 0, width: '30px', orderable: false },
                        { targets: 3, orderable: false },
                        { targets: reviews_tables['reviews'].length - 1, orderable: false },
                        {
                            targets: reviews_tables['reviews'].length - 1,
                            data: 'review_id',
                            render: function (data, type, row) {
                                const protocol = window.location.protocol;
                                const host = window.location.host;
                                const path = '/wp-admin/post.php';
                                const newUrl = new URL(`${protocol}//${host}${path}`);
                                newUrl.searchParams.set('post', data);
                                newUrl.searchParams.set('action', 'edit');

                                return renderReportButton(newUrl.toString(), 'details');
                            }
                        },
                        {
                            targets: reviews_tables['reviews'].length - 3,
                            data: 'rating',
                            render: function (data, type, row) {
                                return renderRating(data);
                            }
                        }
                    ];
                    reviewsTable = createDataTable('#masterstudy-datatable-reviews-table', reviews_tables['reviews'], additionalOptions);
                    observeTableChanges(reviewsTable);
                    hideLoaders('[data-chart-id="reviews-table"]');
                } else {
                    additionalOptions.columnDefs = [
                        { targets: 0,  width: '30px', orderable: false },
                        { targets: 1, orderable: false },
                        { targets: 2, orderable: false },
                    ];

                    if (routes.reviewersTable === currentRoute) {
                        reviewersTable = createDataTable(`#masterstudy-datatable-${currentRoute}`, reviews_tables[currentRoute], additionalOptions);
                        observeTableChanges(reviewersTable, true);
                    } else if (routes.reviewedCoursesTable === currentRoute) {
                        coursesTable = createDataTable(`#masterstudy-datatable-${currentRoute}`, reviews_tables[currentRoute], additionalOptions);
                        observeTableChanges(coursesTable, true);
                    }
                    hideLoaders(`[data-chart-id="${currentRoute}-table"]`);
                }
            }
        }
    }
})(jQuery);
