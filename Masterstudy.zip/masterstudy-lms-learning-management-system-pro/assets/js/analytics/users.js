(function($) {
    // Fetch data global variables
    let chartsData = null;
    let usersChart = null;
    let instructorsChart = null;
    let instructorsTable = null;
    let studentsTable = null;

    // Fetch data
    fetchDataCharts();

    document.addEventListener('datesUpdated', function(event) {
        fetchDataCharts();
        updateTable(routes.usersStudentTable, true);
        updateTable(routes.usersInstructorTable, true);
    });

    $(document).ready(function() {
        initializeDatepicker('#masterstudy-datepicker-users');

        //Update data
        updateCharts();
        updateTable(routes.usersInstructorTable);
        updateTable(routes.usersStudentTable);
    });

    // Fetch data methods
    function fetchDataCharts() {
        if ( isDomReady ) {
            showLoaders('.masterstudy-analytics-users-page-line');
            showLoaders('.masterstudy-analytics-users-page-stats');
        }

        api.get( routePrefix + routes.usersCharts, { date_from: getDateFrom(), date_to: getDateTo() } )
        .then(result => {
            if (result.error_code) {
                return
            }

            chartsData = {
                total: result.total_users,
                students: result.total_students,
                instructors: result.total_instructors,
                instructors_chart: {
                    period: result.instructors?.period,
                    items: [
                        { label: users_page_data.titles.instructors_chart, values: result.instructors?.values },
                    ]
                },
                users_chart: {
                    period: result.users?.period,
                    items: [
                        { label: users_page_data.titles.users_chart, values: result.users?.values },
                    ]
                },
            }

            updateCharts();
        })
    }

    // Update charts & table methods
    function updateCharts() {
        if (chartsData && isDomReady) {
            if (!usersChart) {
                usersChart = createChart(
                    document.getElementById('masterstudy-line-chart-users').getContext('2d'),
                    'line',
                    chartsData.users_chart.period,
                    chartsData.users_chart.items.map((item, index) => ({
                        label: item.label,
                        data: item.values
                    }))
                );
            }

            if (!instructorsChart) {
                instructorsChart = createChart(document.getElementById('masterstudy-line-chart-instructors').getContext('2d'), 'line');
            }

            updateStatsBlock('.masterstudy-stats-block_total', chartsData.total);
            updateStatsBlock('.masterstudy-stats-block_students', chartsData.students);
            updateStatsBlock('.masterstudy-stats-block_instructors', chartsData.instructors);
            updateTotal('#instructors-total', chartsData.instructors);
            updateTotal('#users-total', chartsData.total);
            updateLineChart(usersChart, chartsData.users_chart.period, chartsData.users_chart.items);
            updateLineChart(instructorsChart, chartsData.instructors_chart.period, chartsData.instructors_chart.items);

            hideLoaders('.masterstudy-analytics-users-page-line');
            hideLoaders('.masterstudy-analytics-users-page-stats');
        }
    }

    function updateTable(currentRoute, reloadTable = false) {
        if (isDomReady) {
            if (!instructorsTable || !studentsTable || reloadTable) {
                showLoaders(`[data-chart-id="${currentRoute}-table"]`);

                if (routes.usersInstructorTable === currentRoute && reloadTable) {
                    instructorsTable.clear().destroy();
                    instructorsTable = null;
                    $(`#masterstudy-datatable-${currentRoute}`).empty();
                }

                if (routes.usersStudentTable === currentRoute && reloadTable) {
                    studentsTable.clear().destroy();
                    studentsTable = null;
                    $(`#masterstudy-datatable-${currentRoute}`).empty();
                }

                additionalOptions = {
                    ajax: {
                        url: api.getRouteUrl(routePrefix + currentRoute),
                        type: 'GET',
                        dataType: 'json',
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('X-WP-Nonce', api.getRouteNonce());
                        },
                        data: function (d) {
                            d.date_from = getDateFrom();
                            d.date_to = getDateTo();
                        },
                        dataSrc: function (json) {
                            const pageInfo = $(`#masterstudy-datatable-${currentRoute}`).DataTable().page.info();
                            const start = pageInfo.start;

                            json.data = json.data.map((item, index) => {
                                item.number = start + index + 1;
                                return item;
                            });

                            updateTotal( `#${currentRoute}-table-total`, json.recordsTotal);

                            return json.data;
                        }
                    },
                    columnDefs: [
                        { targets: 0, width: '30px', orderable: false },
                        { targets: users_page_data[currentRoute].length - 1, orderable: false },
                        {
                            targets: users_page_data[currentRoute].length - 1,
                            data: routes.usersInstructorTable === currentRoute ? 'instructor_id' : 'student_id',
                            render: function (data, type, row) {
                                const currentUrl = window.location.href;
                                const newUrl = new URL(currentUrl);
                                const role = routes.usersInstructorTable === currentRoute ? 'instructor' : 'student';
                                newUrl.searchParams.set('user_id', data);
                                newUrl.searchParams.set('user', row.name);
                                newUrl.searchParams.set('role', role);

                                return renderReportButton(newUrl);
                            }
                        }
                    ]
                };

                if (routes.usersInstructorTable === currentRoute) {
                    instructorsTable = createDataTable(`#masterstudy-datatable-${currentRoute}`, users_page_data[currentRoute], additionalOptions);
                    observeTableChanges(instructorsTable);
                } else if (routes.usersStudentTable === currentRoute) {
                    studentsTable = createDataTable(`#masterstudy-datatable-${currentRoute}`, users_page_data[currentRoute], additionalOptions);
                    observeTableChanges(studentsTable);
                }

                hideLoaders(`[data-chart-id="${currentRoute}-table"]`);
            }
        }
    }
})(jQuery);