(function($) {
    // Fetch data global variables
    let chartsData = null;
    let revenueChart = null;
    let enrollmentsChart = null;
    let preordersChart = null;
    let enrollmentsStatusChart = null;
    let assignmentsChart = null;
    let table = null;

    // Fetch data
    fetchDataCharts();

    document.addEventListener('datesUpdated', function(event) {
        fetchDataCharts();
        updateTable(routes.courseLessonsTable, true);
    });

    $(document).ready(function() {
        initializeDatepicker('#masterstudy-datepicker-course');

        //Update data
        updateCharts();
        updateTable(routes.courseLessonsTable);
    });

    // Fetch data methods
    function fetchDataCharts() {
        if ( isDomReady ) {
            showLoaders('.masterstudy-analytics-course-page-line');
            showLoaders('.masterstudy-analytics-course-page-stats');
            showLoaders('.masterstudy-analytics-course-page-doughnut');
        }

        api.get( routePrefix + routes.courseCharts, { date_from: getDateFrom(), date_to: getDateTo() } )
        .then(result => {
            if (result.error_code) {
                return
            }

            chartsData = {
                revenue: result.total_revenue,
                total_enrollments: result.total_enrollments,
                reviews: result.reviews,
                certificates: result.certificates,
                orders_count: result.orders_count,
                lessons: 0,
                preorders: result.preorders_count,
                assignments: result.total_assignments,
                revenue_chart: {
                    period: result.earnings?.period,
                    items: [
                        { label: course_page_data.titles.revenue_chart, values: result.earnings?.values },
                    ]
                },
                enrollments_chart: {
                    period: result.enrollments.period,
                    items: [
                        { label: course_page_data.titles.enrollments_chart, values: result.enrollments.values },
                    ]
                },
                preorders_chart: {
                    period: result.preorders?.period,
                    items: [
                        { label: course_page_data.titles.preorders_chart, values: result.preorders?.values },
                    ]
                },
                enrollments_status: {
                    labels: course_page_data.titles.enrollments_status,
                    values: [result.courses_by_status.not_started, result.courses_by_status.in_progress, result.courses_by_status.completed],
                    percents: getPercentesByValues(
                        [result.courses_by_status.not_started, result.courses_by_status.in_progress, result.courses_by_status.completed]
                    ),
                },
                assignments_chart: {
                    labels: course_page_data.titles.assignments_chart,
                    values: Object.values(result.assignments),
                    percents: getPercentesByValues(Object.values(result.assignments)),
                }
            }

            updateCharts();
        })
    }

    // Update charts & table methods
    function updateCharts() {
        if (chartsData && isDomReady) {
            if (!revenueChart) {
                revenueChart = createChart(document.getElementById('masterstudy-line-chart-revenue').getContext('2d'), 'line', [], [], true);
            }
            if (!preordersChart && stats_data.upcoming_addon) {
                preordersChart = createChart(document.getElementById('masterstudy-line-chart-preorders').getContext('2d'), 'line');
            }
            if (!enrollmentsChart) {
                enrollmentsChart = createChart(
                    document.getElementById('masterstudy-line-chart-enrollments').getContext('2d'),
                    'line',
                    chartsData.enrollments_chart.period,
                    chartsData.enrollments_chart.items.map((item, index) => ({
                        label: item.label,
                        data: item.values
                    }))
                );
            }
            if (!enrollmentsStatusChart) {
                enrollmentsStatusChart = createChart(document.getElementById('masterstudy-doughnut-chart-enrollments-status').getContext('2d'), 'doughnut');
            }
            if (!assignmentsChart && stats_data.assignments_addon) {
                assignmentsChart = createChart(document.getElementById('masterstudy-doughnut-chart-assignments').getContext('2d'), 'doughnut');
            }

            updateStatsBlock('.masterstudy-stats-block_revenue', chartsData.revenue, 'currency');
            updateStatsBlock('.masterstudy-stats-block_enrollments', chartsData.total_enrollments);
            updateStatsBlock('.masterstudy-stats-block_reviews', chartsData.reviews);
            updateStatsBlock('.masterstudy-stats-block_certificates', chartsData.certificates);
            updateStatsBlock('.masterstudy-stats-block_orders', chartsData.orders_count);
            updateTotal('#revenue-total', chartsData.revenue, 'currency');
            updateTotal('#enrollments-total', chartsData.total_enrollments);
            updateTotal('#masterstudy-chart-total-enrollments-status', chartsData.total_enrollments);
            updateTotal('#masterstudy-chart-total-assignments', chartsData.assignments);
            updateLineChart(revenueChart, chartsData.revenue_chart.period, chartsData.revenue_chart.items);
            updateLineChart(enrollmentsChart, chartsData.enrollments_chart.period, chartsData.enrollments_chart.items);
            if ( stats_data.upcoming_addon ) {
                updateTotal('#preorders-total', chartsData.preorders);
                updateLineChart(preordersChart, chartsData.preorders_chart.period, chartsData.preorders_chart.items);
            }
            updateDoughnutChart(enrollmentsStatusChart, chartsData.enrollments_status);
            if ( stats_data.assignments_addon ) {
                updateDoughnutChart(assignmentsChart, chartsData.assignments_chart);
            }

            hideLoaders('.masterstudy-analytics-course-page-line');
            hideLoaders('.masterstudy-analytics-course-page-stats');
            hideLoaders('.masterstudy-analytics-course-page-doughnut');
        }
    }

    function updateTable(currentRoute, reloadTable = false) {
        if (isDomReady) {
            if (!table || reloadTable) {
                showLoaders('.masterstudy-analytics-course-page-table');
                showLoaders('[data-id="all_lessons"]');

                if (table) {
                    table.clear().destroy();
                    table = null;
                    $('#masterstudy-datatable-lessons').empty();
                }

                additionalOptions = {
                    ajax: {
                        url: api.getRouteUrl(routePrefix + currentRoute),
                        type: 'GET',
                        dataType: 'json',
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('X-WP-Nonce', api.getRouteNonce());
                        },
                        data: function (d) {
                            d.date_from = getDateFrom();
                            d.date_to = getDateTo();
                        },
                        dataSrc: function (json) {
                            const pageInfo = $('#masterstudy-datatable-lessons').DataTable().page.info();
                            const start = pageInfo.start;

                            json.data = json.data.map((item, index) => {
                                item.number = start + index + 1;
                                return item;
                            });

                            updateStatsBlock('.masterstudy-stats-block_all_lessons', json.recordsTotal);
                            hideLoaders('[data-id="all_lessons"]');

                            return json.data;
                        }
                    }
                };

                table = createDataTable('#masterstudy-datatable-lessons', course_page_data.lessons, additionalOptions);
                observeTableChanges(table);
                hideLoaders('.masterstudy-analytics-course-page-table');
            }
        }
    }
})(jQuery);
