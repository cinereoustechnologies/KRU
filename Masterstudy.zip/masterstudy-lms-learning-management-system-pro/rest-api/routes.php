<?php

/** @var \MasterStudy\Lms\Plugin $plugin */

$plugin->get_router()->load_routes( __DIR__ . '/Routes/Analytics.php' );
