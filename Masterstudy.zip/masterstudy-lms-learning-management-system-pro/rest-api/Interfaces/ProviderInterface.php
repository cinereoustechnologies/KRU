<?php

namespace MasterStudy\Lms\Pro\RestApi\Interfaces;

interface ProviderInterface {
	public function get_providers(): array;
}
