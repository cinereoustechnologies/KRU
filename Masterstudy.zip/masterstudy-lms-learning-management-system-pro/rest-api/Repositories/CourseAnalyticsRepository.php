<?php

namespace MasterStudy\Lms\Pro\RestApi\Repositories;

class CourseAnalyticsRepository extends AnalyticsRepository {
	public ?int $course_id = null;

	public function __construct( string $date_from, string $date_to, ?int $course_id = null ) {
		$this->course_id = $course_id;

		parent::__construct( $date_from, $date_to );
	}
}
