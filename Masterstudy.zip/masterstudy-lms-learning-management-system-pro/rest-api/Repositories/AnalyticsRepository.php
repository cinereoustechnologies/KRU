<?php

namespace MasterStudy\Lms\Pro\RestApi\Repositories;

class AnalyticsRepository {
	/**
	 * @var \wpdb
	 */
	protected $db;

	protected ?string $date_from;

	protected ?string $date_to;

	public function __construct( string $date_from = null, string $date_to = null ) {
		global $wpdb;

		$this->db        = $wpdb;
		$this->date_from = gmdate( 'Y-m-d 00:00:00', strtotime( $date_from ) );
		$this->date_to   = gmdate( 'Y-m-d 23:59:59', strtotime( $date_to ) );
	}

	public function get_timestamp( string $date ): int {
		return strtotime( $date );
	}

	public function get_period_interval_and_format() {
		$from     = new \DateTime( $this->date_from );
		$to       = new \DateTime( $this->date_to );
		$interval = $from->diff( $to );
		$days     = $interval->days;

		if ( $days <= 61 ) {
			return array( 'P1D', 'm/d' ); // Daily
		} elseif ( $days <= 183 ) {
			return array( 'P1W', 'Y-\WW' ); // Weekly
		} else {
			return array( 'P1M', 'Y-m' ); // Monthly
		}
	}

	public function get_date_periods( $interval_format, $date_format ) {
		$period = new \DatePeriod(
			new \DateTime( $this->date_from ),
			new \DateInterval( $interval_format ),
			new \DateTime( $this->date_to )
		);

		$periods = array();
		foreach ( $period as $date ) {
			$periods[] = $date->format( $date_format );
		}

		return $periods;
	}
}
