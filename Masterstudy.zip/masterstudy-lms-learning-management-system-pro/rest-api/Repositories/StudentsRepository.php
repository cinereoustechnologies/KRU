<?php

namespace MasterStudy\Lms\Pro\RestApi\Repositories;

class StudentsRepository extends DataTableAbstractRepository {

	public function get_students_data( $columns = array(), $order = array() ): array {
		$this->apply_sort( $order, $columns, 'enrollments' );

		$query = "
            SELECT 
                u.ID,
                u.display_name AS name,
                COALESCE(enrollments.enrollments_count, 0) AS enrollments,
                COALESCE(reviews.reviews_count, 0) AS reviews,
                u.user_registered AS joined
            FROM {$this->db->users} u
            LEFT JOIN (
                SELECT user_id, COUNT(course_id) AS enrollments_count
                FROM {$this->db->prefix}stm_lms_user_courses
                GROUP BY user_id
            ) enrollments ON u.ID = enrollments.user_id
            LEFT JOIN (
                SELECT p.post_author AS user_id, COUNT(*) AS reviews_count
                FROM {$this->db->posts} p
                INNER JOIN {$this->db->postmeta} pm ON p.ID = pm.post_id
                WHERE p.post_type = 'stm-reviews'
                AND p.post_status = 'publish'
                AND pm.meta_key = 'review_mark'
                GROUP BY p.post_author
            ) reviews ON u.ID = reviews.user_id
            WHERE 1=1
            ORDER BY {$this->sort_by} {$this->sort_dir}
            LIMIT {$this->limit} OFFSET {$this->start}
        ";

		$prepared_query = $this->db->prepare( $query );

		return $this->db->get_results( $prepared_query, ARRAY_A );
	}
}
