<?php
namespace MasterStudy\Lms\Pro\RestApi\Repositories;

use MasterStudy\Lms\Plugin\PostType;

class ReviewRepository extends DataTableAbstractRepository {
	public function get_reviewed_courses_data(): array {
		$this->apply_sort( array(), array(), 'reviews' );

		$this->select   = array(
			'courses.ID AS course_id',
			'courses.post_title AS name',
			'COALESCE(COUNT(review.ID), 0) as reviews',
		);
		$this->group_by = array( 'courses.ID' );

		// Select aggregate tables
		$this->get_query();

		// Select Groups
		$sql = 'SELECT ' . implode( ',', $this->select ) . " FROM {$this->db->posts} AS courses\n";

		$this->join[] = "LEFT JOIN {$this->db->postmeta} AS meta ON meta.meta_value = courses.ID AND meta.meta_key = 'review_course'";
		$this->join[] = "LEFT JOIN {$this->db->posts} AS review ON review.ID = meta.post_id AND review.post_status = 'publish' AND review.post_date BETWEEN '{$this->date_from}' AND '{$this->date_to}' ";

		$sql .= implode( "\n", $this->join ) . "\n";
		$sql .= "WHERE courses.post_type = '%s'";

		$sql .= $this->group_query();
		// Add order, limit & offset
		$sql .= $this->pagination_query();

		return $this->db->get_results(
			$this->db->prepare( $sql, PostType::COURSE ),
			ARRAY_A
		);
	}

	public function get_reviewers_data(): array {
		$this->apply_sort( array(), array(), 'reviews' );

		$this->select   = array(
			'users.ID AS user_id',
			'COALESCE(NULLIF(CONCAT_WS(" ",fname.meta_value, lname.meta_value),""), users.user_login) as name',
			'COUNT(reviews.ID) AS reviews',
		);
		$this->group_by = array(
			'users.ID',
			'fname.meta_value',
			'lname.meta_value',
		);

		$sql = 'SELECT ' . implode( ',', $this->select ) . " FROM {$this->db->users} AS users\n";

		$this->join[] = "INNER JOIN {$this->db->usermeta} fname ON users.ID = fname.user_id AND fname.meta_key = 'first_name'";
		$this->join[] = "INNER JOIN {$this->db->usermeta} lname ON users.ID = lname.user_id AND lname.meta_key = 'last_name'";
		$this->join[] = "LEFT JOIN {$this->db->posts} AS reviews ON reviews.post_author = users.ID AND reviews.post_type = %s AND reviews.post_status = 'publish' 
		 AND reviews.post_date BETWEEN '{$this->date_from}' AND '{$this->date_to}'";

		$sql .= implode( "\n", $this->join ) . "\n";
		$sql .= $this->group_query();

		// Add order, limit & offset
		$sql .= $this->pagination_query();

		return $this->db->get_results(
			$this->db->prepare( $sql, PostType::REVIEW ),
			ARRAY_A
		);
	}

	public function get_reviews_data( string $status, $columns = array(), $order = array() ) {
		$this->apply_sort( $order, $columns, 'date_created' );

		$this->select = array(
			'reviews.ID AS review_id',
			'reviews.post_date AS date_created',
			'DATE_FORMAT(reviews.post_date, "%d.%m.%Y %k:%i") AS date_created_view',
			'course.post_title AS course_name',
			'reviews.post_content AS review',
			'rating.meta_value AS rating',
			'COALESCE(NULLIF(CONCAT_WS(" ",fname.meta_value, lname.meta_value),""), users.user_login) AS user_name',
		);

		$this->group_by = array(
			'reviews.ID',
			'fname.meta_value',
			'lname.meta_value',
			'course.post_title',
			'rating.meta_value',
		);

		$this->post_type = 'stm-reviews';

		$sql = 'SELECT ' . implode( ',', $this->select ) . " FROM {$this->db->posts} AS reviews\n";

		$this->join[] = "INNER JOIN {$this->db->usermeta} fname ON reviews.post_author = fname.user_id AND fname.meta_key = 'first_name'";
		$this->join[] = "INNER JOIN {$this->db->usermeta} lname ON reviews.post_author = lname.user_id AND lname.meta_key = 'last_name'";
		$this->join[] = "INNER JOIN {$this->db->users} users ON reviews.post_author = users.ID";
		$this->join[] = "LEFT JOIN {$this->db->postmeta} AS meta ON meta.post_id = reviews.ID AND meta.meta_key = 'review_course'";
		$this->join[] = "LEFT JOIN {$this->db->postmeta} AS rating ON rating.post_id = reviews.ID AND rating.meta_key = 'review_mark'";
		$this->join[] = "LEFT JOIN {$this->db->posts} AS course ON course.ID = meta.meta_value";

		$sql .= implode( "\n", $this->join ) . "\n";

		$sql .= "WHERE reviews.post_status = '{$status}' AND reviews.post_type = '{$this->post_type}' AND reviews.post_date BETWEEN '{$this->date_from}' AND '{$this->date_to}'\n";

		$sql .= $this->group_query();

		// Add order, limit & offset
		$sql .= $this->pagination_query();

		return $this->db->get_results(
			$sql,
			ARRAY_A
		) ?? array();

	}

	public function get_total( $status = array( 'publish' ) ) {
		$status = array_map(
			function( $item ) {
				return '\'' . esc_sql( $item ) . '\'';
			},
			$status
		);
		$status = implode( ', ', $status );

		return $this->db->get_var(
			"SELECT COUNT(*) as count FROM {$this->db->posts} p
             WHERE p.post_type = '{$this->post_type}' AND p.post_status IN ({$status}) AND p.post_date BETWEEN '{$this->date_from}' AND '{$this->date_to}'"
		);
	}

}
