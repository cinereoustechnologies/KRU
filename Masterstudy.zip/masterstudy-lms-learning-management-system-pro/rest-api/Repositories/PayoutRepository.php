<?php

namespace MasterStudy\Lms\Pro\RestApi\Repositories;

use MasterStudy\Lms\Plugin\PostType;

class PayoutRepository extends AnalyticsRepository {
	public function get_payouts() {
		return $this->db->get_row(
			$this->db->prepare(
				"SELECT SUM(pm1.meta_value) as amount, SUM(pm2.meta_value) as instructor_revenue 
				FROM {$this->db->posts} p
				LEFT JOIN {$this->db->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = %s
				LEFT JOIN {$this->db->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = %s
				LEFT JOIN {$this->db->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = %s
				WHERE p.post_type = %s 
				AND p.post_status = 'publish' 
				AND pm3.meta_value = %s
				AND p.post_date BETWEEN %s AND %s",
				'amounts',
				'fee_amounts',
				'status',
				PostType::PAYOUT,
				'SUCCESS',
				$this->date_from,
				$this->date_to
			)
		);
	}
}
