<?php

namespace MasterStudy\Lms\Pro\RestApi\Repositories;

/**
 * Class helper DataTableAbstractRepository
 * For support pagination & sort methods
 */
class DataTableAbstractRepository extends AnalyticsRepository {

	public int $start = 0;

	public int $limit = 10;

	/**
	 * Table of courses (default stm_lms_user_courses)
	 */
	public string $table_courses = '';

	/**
	 * Table of orders (default stm_lms_order_items)
	 */
	public string $table_orders = '';

	public string $sort_by = 'revenue';

	public string $post_type = '';

	public string $sort_dir = 'ASC';

	public array $select = array();

	public array $join = array();

	public array $group_by = array();

	public function __construct( string $date_from, string $date_to, int $start = 0, int $limit = 10 ) {
		parent::__construct( $date_from, $date_to );

		$this->start         = $start;
		$this->limit         = $limit;
		$this->table_courses = stm_lms_user_courses_name( $this->db );
		$this->table_orders  = stm_lms_order_items_name( $this->db );
	}
	/**
	 * Build SQL query
	 */
	public function get_query() {
		return $this;
	}

	/**
	 * Calculate total posts
	 *
	 * @param string $post_type
	 *
	 * @return string
	 */
	public function get_total( $status = array( 'publish' ) ) {
		$status = array_map(
			function( $item ) {
				return '\'' . esc_sql( $item ) . '\'';
			},
			$status
		);
		$status = implode( ', ', $status );

		return $this->db->get_var(
			"SELECT COUNT(*) as count FROM {$this->db->posts} p
             WHERE p.post_type = '{$this->post_type}' AND p.post_status IN ({$status})"
		);
	}

	/**
	 * Calculate order field and direction and apply to values
	 * @param array $order
	 * @param array $columns
	 */
	public function apply_sort( $order = array(), $columns = array(), $default_sort_by = 'revenue' ) {
		if ( ! empty( $columns ) && ! empty( $order ) ) {
			$order  = reset( $order );
			$column = $order['column'] ?? 1;
			$dir    = $order['dir'] ?? 'asc';

			if ( ! empty( $columns[ $column ]['data'] ) && 'number' !== $columns[ $column ]['data'] ) {
				$this->sort_by  = $columns[ $column ]['data'];
				$this->sort_dir = strtoupper( $dir );
				return $this;
			}
		}

		$this->sort_by  = $default_sort_by;
		$this->sort_dir = 'DESC';

		return $this;
	}

	public function pagination_query() {
		$sql = "ORDER BY {$this->sort_by} $this->sort_dir LIMIT {$this->limit}";

		// Add pagination offset
		if ( $this->start > 1 ) {
			$sql .= ' OFFSET ' . $this->start;
		}

		return $sql;
	}

	public function group_query() {
		return 'GROUP BY ' . implode( ',', $this->group_by ) . "\n";
	}
}
