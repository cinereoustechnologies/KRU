<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

class StudentCourseProgressSerializer extends AbstractSerializer {
	public function toArray( $data ): array {
		return array(
			'name'     => $data['name'],
			'duration' => $data['duration'],
			'started'  => gmdate( 'd.m.Y H:i', intval( $data['started'] ) ),
			'progress' => (int) $data['progress'],
		);
	}
}
