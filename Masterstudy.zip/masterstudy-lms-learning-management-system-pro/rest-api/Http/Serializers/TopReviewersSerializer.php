<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

class TopReviewersSerializer extends AbstractSerializer {
	public function toArray( $data ): array {
		return array(
			'student_name' => $data['name'],
			'reviews'      => intval( $data['reviews'] ),
			'student_id'   => intval( $data['student_id'] ),
		);
	}
}
