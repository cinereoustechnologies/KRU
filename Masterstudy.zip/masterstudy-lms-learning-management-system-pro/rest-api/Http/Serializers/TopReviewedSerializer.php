<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

class TopReviewedSerializer extends AbstractSerializer {
	public function toArray( $data ): array {
		return array(
			'name'    => $data['name'],
			'reviews' => intval( $data['reviews'] ),
		);
	}
}
