<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

class StudentsSerializer extends AbstractSerializer {
	public function toArray( $data ): array {
		return array(
			'student_id'  => intval( $data['ID'] ),
			'name'        => $data['name'],
			'enrollments' => intval( $data['enrollments'] ),
			'reviews'     => intval( $data['reviews'] ),
			'joined'      => gmdate( 'd.m.Y H:i', strtotime( $data['joined'] ) ),
		);
	}
}
