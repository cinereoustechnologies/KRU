<?php
namespace MasterStudy\Lms\Pro\RestApi\Http\Controllers\Analytics;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\RestApi\Http\Serializers\LessonSerializer;
use MasterStudy\Lms\Pro\RestApi\Repositories\LessonRepository;
use MasterStudy\Lms\Repositories\CourseRepository;
use WP_REST_Request;
use WP_REST_Response;

final class GetLessonsCourseController extends Controller {

	public function __invoke( int $course_id, WP_REST_Request $request ): WP_REST_Response {
		if ( ! ( new CourseRepository() )->exists( $course_id ) ) {
			return WpResponseFactory::not_found();
		}

		$validation = $this->validate(
			$request,
			array(
				'start'   => 'required|integer',
				'length'  => 'required|integer',
				'order'   => 'array',
				'columns' => 'array',
			),
		);

		if ( $validation instanceof WP_REST_Response ) {
			return $validation;
		}

		$validated_date    = $this->get_validated_data();
		$course_repository = ( new LessonRepository(
			$this->get_date_from(),
			$this->get_date_to(),
			$validated_date['start'] ?? 1,
			$validated_date['length'] ?? 10,
		) );

		// Sort by: revenue, courses, orders, name. Example: sort[name] = asc
		$lessons       = $course_repository->get_lessons_data(
			$course_id,
			$validated_date['columns'] ?? array(),
			$validated_date['order'] ?? array()
		);
		$total_lessons = $course_repository->get_total_lessons( $course_id );

		return new WP_REST_Response(
			array(
				'recordsTotal'    => $total_lessons,
				'recordsFiltered' => $total_lessons,
				'data'            => ( new LessonSerializer() )->collectionToArray( $lessons ),
			)
		);
	}
}
