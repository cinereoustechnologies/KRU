<?php
namespace MasterStudy\Lms\Pro\RestApi\Http\Controllers\Analytics;

use MasterStudy\Lms\Pro\RestApi\Http\Serializers\ReviewsSerializer;
use MasterStudy\Lms\Pro\RestApi\Repositories\ReviewRepository;
use WP_REST_Request;
use WP_REST_Response;

final class GetReviewsController extends Controller {
	public function __invoke( string $status, WP_REST_Request $request ): WP_REST_Response {
		$validation = $this->validate(
			$request,
			array(
				'start'   => 'required|integer',
				'length'  => 'required|integer',
				'order'   => 'array',
				'columns' => 'array',
			),
		);

		if ( $validation instanceof WP_REST_Response ) {
			return $validation;
		}

		$validated_date    = $this->get_validated_data();
		$review_repository = new ReviewRepository(
			$this->get_date_from(),
			$this->get_date_to(),
			$validated_date['start'] ?? 1,
			$validated_date['length'] ?? 10,
		);

		$reviews       = $review_repository->get_reviews_data(
			$status,
			$validated_date['columns'] ?? array(),
			$validated_date['order'] ?? array()
		);
		$reviews_total = $review_repository->get_total( array( $status ) );

		return new WP_REST_Response(
			array(
				'recordsTotal'    => $reviews_total,
				'recordsFiltered' => $reviews_total,
				'data'            => ( new ReviewsSerializer() )->collectionToArray( $reviews ),
			)
		);
	}
}
