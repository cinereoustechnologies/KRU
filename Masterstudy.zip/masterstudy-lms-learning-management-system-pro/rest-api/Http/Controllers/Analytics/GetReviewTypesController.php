<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Controllers\Analytics;

use MasterStudy\Lms\Pro\RestApi\Repositories\GetReviewTypesRepository;
use MasterStudy\Lms\Pro\RestApi\Http\Serializers\ReviewTypesSerializer;
use WP_REST_Request;
use WP_REST_Response;

final class GetReviewTypesController extends Controller {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validation = $this->validate( $request );

		if ( $validation instanceof WP_REST_Response ) {
			return $validation;
		}

		$reviews_repository = new GetReviewTypesRepository(
			$this->get_date_from(),
			$this->get_date_to(),
		);

		$reviews_data = $reviews_repository->get_reviews_data();

		return new WP_REST_Response( ( new ReviewTypesSerializer() )->toArray( $reviews_data ) );
	}
}
