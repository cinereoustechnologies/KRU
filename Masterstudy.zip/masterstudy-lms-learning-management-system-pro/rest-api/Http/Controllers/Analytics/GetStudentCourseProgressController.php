<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Controllers\Analytics;

use MasterStudy\Lms\Pro\RestApi\Http\Serializers\StudentCourseProgressSerializer;
use MasterStudy\Lms\Pro\RestApi\Repositories\StudentCourseProgressRepository;
use WP_REST_Request;
use WP_REST_Response;

final class GetStudentCourseProgressController extends Controller {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validation = $this->validate(
			$request,
			array(
				'start'   => 'required|integer',
				'length'  => 'required|integer',
				'order'   => 'array',
				'columns' => 'array',
				'user_id' => 'required|integer',
			)
		);

		if ( $validation instanceof WP_REST_Response ) {
			return $validation;
		}

		$validated_data = $this->get_validated_data();
		$student_id     = $validated_data['user_id'];

		$students_repository = new StudentCourseProgressRepository(
			$this->get_date_from(),
			$this->get_date_to(),
			$validated_data['start'] ?? 0,
			$validated_data['length'] ?? 10
		);

		$students = $students_repository->get_student_course_progress_data(
			$validated_data['columns'],
			array_key_exists( 'order', $validated_data ) ? $validated_data['order'] : null,
			$student_id
		);

		$total = $students_repository->get_total_student_courses( $student_id );

		return new WP_REST_Response(
			array(
				'recordsTotal'    => intval( $total ),
				'recordsFiltered' => intval( $total ),
				'data'            => ( new StudentCourseProgressSerializer() )->collectionToArray( $students ),
			)
		);
	}
}
