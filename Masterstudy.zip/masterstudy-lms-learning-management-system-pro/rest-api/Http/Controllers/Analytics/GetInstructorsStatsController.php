<?php

namespace MasterStudy\Lms\Pro\RestApi\Http\Controllers\Analytics;

use MasterStudy\Lms\Pro\RestApi\Http\Serializers\InstructorsSerializer;
use MasterStudy\Lms\Pro\RestApi\Repositories\InstructorsRepository;
use WP_REST_Request;
use WP_REST_Response;

final class GetInstructorsStatsController extends Controller {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validation = $this->validate(
			$request,
			array(
				'start'   => 'required|integer',
				'length'  => 'required|integer',
				'order'   => 'array',
				'columns' => 'array',
			)
		);

		if ( $validation instanceof WP_REST_Response ) {
			return $validation;
		}

		$validated_data         = $this->get_validated_data();
		$instructors_repository = new InstructorsRepository(
			$this->get_date_from(),
			$this->get_date_to(),
			$validated_data['start'] ?? 0,
			$validated_data['length'] ?? 10
		);

		$instructors = $instructors_repository->get_instructors_data(
			$validated_data['columns'],
			$validated_data['order']
		);
		$total       = $instructors_repository->get_total_instructors();

		$responseData = array(
			'recordsTotal'    => intval( $total ),
			'recordsFiltered' => intval( $total ),
			'data'            => ( new InstructorsSerializer() )->collectionToArray( $instructors ),
		);

		return new WP_REST_Response( $responseData );
	}
}
