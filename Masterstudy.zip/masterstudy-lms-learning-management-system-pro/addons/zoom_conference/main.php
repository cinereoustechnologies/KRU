<?php
require_once STM_LMS_PRO_ADDONS . '/zoom_conference/zoom_plugins/zoom.php';
