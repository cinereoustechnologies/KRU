## Installation

```bash
composer install --ignore-platform-reqs --no-dev --no-plugins --no-progress;

npm install;
gulp build;
```