<?php

include_once DEON_INC_ROOT_DIR . '/search/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
