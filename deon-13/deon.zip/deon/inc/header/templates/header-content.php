<?php

// Include logo
deon_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
deon_template_part( 'header', 'templates/parts/navigation' );
