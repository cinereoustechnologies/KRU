<div class="qodef-m-content qodef-content-grid">
	<h1 class="qodef-m-title entry-title"><?php echo esc_html( deon_get_page_title_text() ); ?></h1>
</div>
