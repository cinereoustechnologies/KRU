<?php

// Include mobile logo
deon_template_part( 'mobile-header', 'templates/parts/mobile-logo' );

// Include mobile navigation opener
deon_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
deon_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );
