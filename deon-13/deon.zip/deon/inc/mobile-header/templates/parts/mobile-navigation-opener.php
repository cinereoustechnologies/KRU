<a class="qodef-mobile-header-opener" href="#"><?php deon_render_svg_icon( 'menu', 'qodef--initial' ); ?></a>
