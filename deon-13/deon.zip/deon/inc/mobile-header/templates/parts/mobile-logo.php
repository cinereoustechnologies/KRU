<a itemprop="url" class="qodef-mobile-header-logo-link qodef-height--not-set" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	<?php
	// Include mobile header logo image html
	echo deon_get_header_logo_image(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	?>
</a>
