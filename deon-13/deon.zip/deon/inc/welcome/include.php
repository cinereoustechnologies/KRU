<?php

include_once DEON_INC_ROOT_DIR . '/welcome/class-deon-welcome-page.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
