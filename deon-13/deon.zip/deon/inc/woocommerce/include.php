<?php

include_once DEON_INC_ROOT_DIR . '/woocommerce/class-deon-woocommerce.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
