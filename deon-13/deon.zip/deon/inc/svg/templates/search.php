<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18.544px" height="19.96px" viewBox="0 0 18.544 19.96" enable-background="new 0 0 18.544 19.96" xml:space="preserve">
<path d="M18.169,18.943l-4.458-4.459c1.651-1.466,2.699-3.598,2.699-5.975c0-4.411-3.589-8-8-8s-8,3.588-8,8s3.589,8,8,8
	c1.673,0,3.227-0.519,4.512-1.399l4.541,4.54L18.169,18.943z M1.41,8.51c0-3.859,3.14-7,7-7s7,3.14,7,7s-3.14,7-7,7
	S1.41,12.369,1.41,8.51z"/>
</svg>