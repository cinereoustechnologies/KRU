<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="90px" height="90px" viewBox="0 0 90 90" enable-background="new 0 0 90 90" xml:space="preserve">
	<circle fill="none" stroke="#C3C4F9" stroke-width="2" stroke-miterlimit="10" cx="45.567" cy="44.925" r="42"></circle>
	<path fill="currentColor" stroke="none" d="M51.662,45.394L40.958,56.019l-1.016-0.938l10.235-10.156L40.021,34.769l0.938-0.938l10.704,10.625V45.394z"></path>
</svg>
