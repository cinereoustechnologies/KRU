<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="26px" viewBox="0 0 15 26">
	<g>
		<path d="M14.106,13.605L2.6,25.027L1.508,24.02L12.51,13.102L1.592,2.184L2.6,1.176l11.506,11.422V13.605z"/>
	</g>
</svg>
