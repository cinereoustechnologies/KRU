<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg"
     xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="25px" viewBox="0 0 25 25">
<g>
	<path d="M15.559,9.422h7.916l-6.48,5.045l2.912,8.654l-7.219-5.414l-7.219,5.414l2.912-8.654L1.9,9.422h7.916l2.871-8.203
		L15.559,9.422z"/>
</g>
</svg>