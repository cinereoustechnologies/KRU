<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="26px" viewBox="0 0 15 26">
<g>
	<path d="M1.508,12.598L13.014,1.176l1.008,1.008L3.104,13.102L14.106,24.02l-1.092,1.008L1.508,13.605V12.598z"/>
</g>
</svg>
