<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg"
     xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
     width="15px" height="15px" viewBox="0 0 31 31" xml:space="preserve">
<rect x="-4" y="15" transform="matrix(0.7071 0.7071 -0.7071 0.7071 15.5005 -6.4201)" width="39" height="2"/>
	<rect x="-4" y="14.999" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.4201 15.5001)" width="39.001"
	      height="2"/>
</svg>