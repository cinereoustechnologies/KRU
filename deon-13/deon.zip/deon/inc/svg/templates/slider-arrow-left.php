<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="90px" height="90px" viewBox="0 0 90 90" enable-background="new 0 0 90 90" xml:space="preserve">
	<circle fill="none" stroke="#C3C4F9" stroke-width="2" stroke-miterlimit="10" cx="45.567" cy="44.925" r="42"></circle>
	<path fill="currentColor" stroke="none" d="M39.9,45.4L50.6,56l1-0.9L41.4,44.9l10.2-10.2l-0.9-0.9L39.9,44.5L39.9,45.4L39.9,45.4z"/>
</svg>