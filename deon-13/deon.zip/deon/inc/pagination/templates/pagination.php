<?php

// Backup template if there is no pagination
