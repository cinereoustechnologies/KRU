<?php

include_once DEON_INC_ROOT_DIR . '/rest/class-deon-rest-api.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
