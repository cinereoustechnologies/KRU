<?php

require_once DEON_INC_ROOT_DIR . '/plugins/class-tgm-plugin-activation.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
include_once DEON_INC_ROOT_DIR . '/plugins/plugins-activation.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
