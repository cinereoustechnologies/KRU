<?php

define( 'DEON_ROOT', get_template_directory_uri() );
define( 'DEON_ROOT_DIR', get_template_directory() );
define( 'DEON_ASSETS_ROOT', DEON_ROOT . '/assets' );
define( 'DEON_ASSETS_ROOT_DIR', DEON_ROOT_DIR . '/assets' );
define( 'DEON_ASSETS_CSS_ROOT', DEON_ASSETS_ROOT . '/css' );
define( 'DEON_ASSETS_CSS_ROOT_DIR', DEON_ASSETS_ROOT_DIR . '/css' );
define( 'DEON_ASSETS_JS_ROOT', DEON_ASSETS_ROOT . '/js' );
define( 'DEON_ASSETS_JS_ROOT_DIR', DEON_ASSETS_ROOT_DIR . '/js' );
define( 'DEON_INC_ROOT', DEON_ROOT . '/inc' );
define( 'DEON_INC_ROOT_DIR', DEON_ROOT_DIR . '/inc' );
