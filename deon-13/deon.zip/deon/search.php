<?php

get_header();

// Include content template
deon_template_part( 'content', 'templates/content', 'search' );

get_footer();
